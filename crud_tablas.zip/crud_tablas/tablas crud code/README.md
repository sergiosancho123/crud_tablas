# CRUD Nodejs and Mysql
Basic app crud with nodejs n mysql as db.

fork from https://github.com/FaztWeb/crud-nodejs-mysql
# Usefull Commands
- To init mysql: `mysql -u root -p`

# links
- [bootstrap 4 theme](https://bootswatch.com/4/lux/bootstrap.min.css)
